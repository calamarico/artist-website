function Hero() {
  const I = window.K_ICONS;
  const D = window.kalamaricoData;
  const [theme, setTheme] = React.useState("green");
  const toggle = () => {
    const next = theme === "green" ? "fire" : "green";
    setTheme(next);
    document.documentElement.dataset.theme = next;
  };
  const avatarSrc = theme === "green" ? "../../assets/avatar-green.jpeg" : "../../assets/avatar-fire.jpeg";

  return (
    <section id="top" className="k-hero">
      <div className="k-hero-grid" aria-hidden></div>
      <div className="k-hero-noise" aria-hidden></div>
      <div className="k-hero-protect" aria-hidden></div>

      <div className="k-hero-inner">
        <div className="k-hero-text">
          <span className="k-chip"><I.Pin size={12} /> {D.location}</span>
          <h1 className="k-wordmark">KALAMARICO</h1>
          <p className="k-hero-tag">{D.tagline}</p>
          <div className="k-hero-ctas">
            <a className="k-btn k-btn-primary"><I.Spotify size={18} /> Listen on Spotify</a>
            <a className="k-btn k-btn-ghost"><I.SoundCloud size={18} /> Follow on SoundCloud</a>
          </div>
        </div>

        <div className="k-hero-avatar" onClick={toggle} role="button" aria-label="Toggle theme">
          <div className="k-avatar-glow" aria-hidden></div>
          <img src={avatarSrc} alt="Kalamarico" className="k-avatar" draggable={false} />
        </div>
      </div>

      <div className="k-hero-scroll" aria-hidden>
        <span></span>
      </div>
    </section>
  );
}
window.Hero = Hero;
