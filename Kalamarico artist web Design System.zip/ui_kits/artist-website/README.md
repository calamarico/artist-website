# Kalamarico — Artist Website UI Kit

A pixel-level recreation of [kalamarico.com](https://kalamarico.com), translated from the production React + Tailwind codebase to plain JSX components that share `colors_and_type.css`.

## Files

- `index.html` — full click-through homepage (Navbar → Hero → About → Tracks → Streaming → Label → Footer)
- `Navbar.jsx` — fixed navbar that turns opaque on scroll
- `Hero.jsx` — wordmark + avatar + CTAs over the grid
- `About.jsx` — bio + label chips, sticky avatar pane
- `Tracks.jsx` — featured 3-up + filterable catalogue grid
- `Streaming.jsx` — streaming + social link grid
- `Label.jsx` — Beta-Time Records CTA card
- `Footer.jsx` — minimal footer
- `data.js` — releases + socials + bio (subset of `src/data/artist.ts`)
- `icons.jsx` — inline-SVG stand-ins for the react-icons used in the site

## Theme swap

`<html data-theme="green">` (default) and `<html data-theme="fire">` swap all accent tokens. The kit doesn't include the avatar particle-canvas choreography — that's owned by the production codebase. Toggle via the avatar in this kit, click and the theme flips.
