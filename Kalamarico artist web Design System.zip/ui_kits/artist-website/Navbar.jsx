function Navbar() {
  const [open, setOpen] = React.useState(false);
  const [scrolled, setScrolled] = React.useState(false);
  const I = window.K_ICONS;

  React.useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 16);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const links = [
    { href: "#about", label: "About" },
    { href: "#tracks", label: "Releases" },
    { href: "#listen", label: "Listen" },
    { href: "#label", label: "Label" }
  ];

  return (
    <header className={"k-nav " + (scrolled ? "is-scrolled" : "")}>
      <nav className="k-nav-inner">
        <a href="#top" className="k-nav-brand">Kalamarico</a>
        <ul className="k-nav-links">
          {links.map(l => (
            <li key={l.href}><a href={l.href}>{l.label}</a></li>
          ))}
        </ul>
        <button className="k-nav-menu" onClick={() => setOpen(o => !o)} aria-label="Menu">
          {open ? <I.X size={20} /> : <I.Menu size={20} />}
        </button>
      </nav>
      {open && (
        <ul className="k-nav-mobile">
          {links.map(l => (
            <li key={l.href}><a href={l.href} onClick={() => setOpen(false)}>{l.label}</a></li>
          ))}
        </ul>
      )}
    </header>
  );
}
window.Navbar = Navbar;
