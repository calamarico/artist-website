function Label() {
  const I = window.K_ICONS;
  return (
    <section id="label" className="k-section k-section-900">
      <div className="k-container">
        <div className="k-label-card">
          <div className="k-label-blob k-blob-tl" aria-hidden></div>
          <div className="k-label-blob k-blob-br" aria-hidden></div>
          <div className="k-label-grid-bg" aria-hidden></div>

          <div className="k-label-body">
            <p className="k-eyebrow">The Label</p>
            <h2 className="k-h1" style={{marginTop:12}}>Beta-Time Records</h2>
            <span className="k-chip k-chip-accent" style={{marginTop:14}}>
              <span className="k-chip-dot"></span>Co-CEO
            </span>
            <p className="k-body-lg" style={{marginTop:32, maxWidth:560}}>
              Curating and releasing electronic music that pushes the boundaries of techno and electronic sound.
            </p>
            <div className="k-label-ctas">
              <a className="k-btn k-btn-primary"><I.External size={18} /> Visit website</a>
              <a className="k-btn k-btn-quiet"><I.Beatport size={18} /> Beatport</a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
window.Label = Label;
