function Footer() {
  const links = [
    { href: "#about", label: "About" },
    { href: "#tracks", label: "Releases" },
    { href: "#listen", label: "Listen" },
    { href: "#label", label: "Label" }
  ];
  return (
    <footer className="k-footer">
      <div className="k-container k-footer-inner">
        <div>
          <p className="k-footer-brand">Kalamarico</p>
          <p className="k-footer-meta">© 2025 Kalamarico / Beta-Time Records</p>
        </div>
        <nav>
          <ul className="k-footer-links">
            {links.map(l => <li key={l.href}><a href={l.href}>{l.label}</a></li>)}
          </ul>
        </nav>
      </div>
    </footer>
  );
}
window.Footer = Footer;
