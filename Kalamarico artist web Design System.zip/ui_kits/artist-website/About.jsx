function About() {
  const D = window.kalamaricoData;
  return (
    <section id="about" className="k-section k-section-950">
      <div className="k-container k-about-grid">
        <div className="k-about-portrait">
          <div className="k-portrait-frame">
            <img src="../../assets/avatar-green.jpeg" alt="Kalamarico portrait" />
          </div>
          <span className="k-chip" style={{marginTop: 24}}>
            <span className="k-chip-dot"></span>
            <span className="k-mono" style={{textTransform:"uppercase",letterSpacing:"0.18em",fontSize:11}}>
              Kalamarico — Madrid
            </span>
          </span>
        </div>

        <div className="k-about-body">
          <p className="k-eyebrow">About</p>
          <h2 className="k-h1" style={{marginTop:12}}>
            Sound exploration, <span className="k-text-gradient">always evolving</span>.
          </h2>
          <div className="k-bio">
            {D.bio.map((p, i) => <p key={i}>{p}</p>)}
          </div>
          <div style={{marginTop:32}}>
            <p className="k-caption">Released on</p>
            <ul className="k-label-list">
              {D.labels.map(l => <li key={l}>{l}</li>)}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}
window.About = About;
