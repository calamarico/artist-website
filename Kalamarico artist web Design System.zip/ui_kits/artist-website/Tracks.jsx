function Tracks() {
  const D = window.kalamaricoData;
  const I = window.K_ICONS;
  const [filter, setFilter] = React.useState("all");

  const featured = D.releases.slice(0, 3);
  const filtered = filter === "all"
    ? D.releases
    : D.releases.filter(r => r.type === (filter === "ep" ? "EP" : "SINGLE"));

  const fmt = d => {
    const dt = new Date(d);
    return dt.toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" });
  };
  const yr = d => new Date(d).getUTCFullYear();

  const counts = {
    all: D.releases.length,
    single: D.releases.filter(r => r.type === "SINGLE").length,
    ep: D.releases.filter(r => r.type === "EP").length
  };

  const Cover = ({ release, big }) => (
    <div className={big ? "k-cover-big" : "k-cover"} style={{
      background: `linear-gradient(135deg, ${release.color[0]} 0%, ${release.color[1]} 60%, #050507 100%)`
    }}>
      <span className="k-cover-meta">
        {release.type === "EP" ? `EP · ${release.trackCount}` : "Single"}
      </span>
      <span className="k-cover-title">{release.name}</span>
    </div>
  );

  return (
    <section id="tracks" className="k-section k-section-900">
      <div className="k-container">
        <div className="k-section-header">
          <div>
            <p className="k-eyebrow">Discography</p>
            <h2 className="k-h1" style={{marginTop:12}}>
              Latest <span className="k-text-gradient">Releases</span>
            </h2>
          </div>
          <p className="k-section-sub">My latest three. Full catalogue follows.</p>
        </div>

        <ul className="k-featured-grid">
          {featured.map(r => (
            <li key={r.id}>
              <a className="k-featured-card">
                <Cover release={r} big />
                <div className="k-featured-body">
                  <span className="k-caption">{fmt(r.date)}</span>
                  <h3 className="k-h3" style={{marginTop:8,color:"#fff"}}>{r.name}</h3>
                  <div className="k-featured-foot">
                    <span className="k-listen"><I.Spotify size={16} /> Play on Spotify</span>
                    <span className="k-play-circle"><I.Play size={20} /></span>
                  </div>
                </div>
              </a>
            </li>
          ))}
        </ul>

        <div className="k-section-header" style={{marginTop:96}}>
          <div>
            <p className="k-eyebrow">Full catalogue</p>
            <h2 className="k-h1" style={{marginTop:12}}>Every release, in one place</h2>
            <p className="k-body" style={{marginTop:16,maxWidth:540}}>
              {counts.all} releases on Spotify — singles and EPs from 2022 to today.
            </p>
          </div>

          <div className="k-tabs" role="tablist">
            {[
              { k: "all", label: "All", n: counts.all },
              { k: "single", label: "Singles", n: counts.single },
              { k: "ep", label: "EPs", n: counts.ep }
            ].map(t => (
              <button
                key={t.k}
                className={"k-tab " + (filter === t.k ? "is-active" : "")}
                onClick={() => setFilter(t.k)}
              >
                {t.label} <span className="k-tab-count">{t.n}</span>
              </button>
            ))}
          </div>
        </div>

        <ul className="k-catalogue-grid">
          {filtered.map(r => (
            <li key={r.id}>
              <a className="k-catalogue-card">
                <Cover release={r} />
                <div className="k-catalogue-body">
                  <h3 className="k-cat-title">{r.name}</h3>
                  <span className="k-cat-year">{yr(r.date)}</span>
                </div>
              </a>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
window.Tracks = Tracks;
