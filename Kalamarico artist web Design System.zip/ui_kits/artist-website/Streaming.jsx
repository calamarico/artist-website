function Streaming() {
  const D = window.kalamaricoData;
  const I = window.K_ICONS;

  const stream = D.socials.filter(s => s.kind === "stream");
  const social = D.socials.filter(s => s.kind === "social");

  const Tile = ({ s }) => {
    const Glyph = I[s.label.replace(/\s/g, "")] || I[s.label] || I.External;
    return (
      <li>
        <a className="k-stream-link">
          <Glyph size={18} />
          <span>{s.label}</span>
        </a>
      </li>
    );
  };

  return (
    <section id="listen" className="k-section k-section-950">
      <div className="k-container">
        <p className="k-eyebrow">Everywhere</p>
        <h2 className="k-h1" style={{marginTop:12}}>
          Listen & <span className="k-text-gradient">Download</span>
        </h2>
        <p className="k-body" style={{marginTop:16, maxWidth:540, color:"var(--fg-4)"}}>
          Stream Kalamarico on every major platform, or follow on social for the latest drops.
        </p>

        <div style={{marginTop:56}}>
          <p className="k-caption">Streaming &amp; stores</p>
          <ul className="k-stream-grid">{stream.map(s => <Tile key={s.label} s={s} />)}</ul>
        </div>
        <div style={{marginTop:56}}>
          <p className="k-caption">Social</p>
          <ul className="k-stream-grid">{social.map(s => <Tile key={s.label} s={s} />)}</ul>
        </div>
      </div>
    </section>
  );
}
window.Streaming = Streaming;
