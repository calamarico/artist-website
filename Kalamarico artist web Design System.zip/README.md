# Kalamarico Design System

The visual + content system for **Kalamarico** — Madrid-based electronic music producer / techno DJ and Co‑CEO of **Beta‑Time Records**. The product is a single‑page artist website at [kalamarico.com](https://kalamarico.com) — a streaming‑forward, dark, neon, slightly‑cyberpunk artist hub.

This system is sourced 1:1 from the production codebase and the live site:

| Source | Where |
| --- | --- |
| Codebase | `calamarico/artist-website` (React 18 + Vite + Tailwind v3 + framer‑motion) |
| Live site | https://kalamarico.com |
| Brand artwork | `assets/avatar-green.jpeg`, `assets/avatar-fire.jpeg` (1024×1024 painted portraits) |
| Stack notes | TypeScript strict, react‑icons (FA + Si), no extra UI lib — all components hand‑rolled with Tailwind tokens |

The system is not a generic dark theme. It is a **two‑state identity** that swaps live, in‑page, between a **GREEN** (lime + ember orange complement) and **FIRE** (orange + lime complement) accent palette, triggered by interacting with the artist avatar.

---

## Index

```
Kalamarico Design System/
├── README.md                  ← you are here
├── SKILL.md                   Agent‑Skill manifest (cross‑compatible)
├── colors_and_type.css        Drop‑in stylesheet: tokens + theme swap
├── assets/                    Logos / avatars / favicons
│   ├── avatar-green.jpeg      Primary brand avatar (idle state)
│   ├── avatar-fire.jpeg       Complement avatar (intro / hover state)
│   ├── apple-touch-icon.png   180×180
│   ├── favicon-32x32.png
│   ├── favicon-64x64.png
│   └── og-image.jpg           Social card
├── preview/                   Design‑system reference cards
│   ├── colors-*.html
│   ├── type-*.html
│   ├── components-*.html
│   └── …
└── ui_kits/
    └── artist-website/        Pixel‑level recreation of kalamarico.com
        ├── README.md
        ├── index.html         Live click‑through
        ├── Navbar.jsx
        ├── Hero.jsx
        ├── About.jsx
        ├── Tracks.jsx
        ├── Streaming.jsx
        ├── Label.jsx
        └── Footer.jsx
```

---

## Brand at a glance

- **Name** Kalamarico (the producer alias of an electronic / techno artist)
- **Location** Madrid, Spain
- **Role** Electronic Music Producer | Co‑CEO of **Beta‑Time Records**
- **Tone** Personal, technical, understated. First person. Lowercase moods, ALL‑CAPS for the wordmark only.
- **Vibe** Dark room, green laser, ember sparks, neon cyberpunk skyline. Sound‑first. Stream‑forward.
- **Active labels** Beta‑Time Records, Vanta Record, Techno Drum Records, Nothing But.

---

## Content fundamentals

### Voice

Kalamarico writes from the producer's chair, in the **first person**. The bio is autobiographical and technical: it talks about FastTracker, hybrid hardware/software setups, "rhythmic structure and atmospheric depth" — not marketing copy. The label voice is third person and slightly more institutional.

Real examples from the site:

> "Since my first sequences in FastTracker nearly 30 years ago, I've developed a creative approach focused on sound exploration, electronic texture design, and technical evolution in music production."

> "Continuous improvement — both in mixing and composition — is a core part of my creative process."

> "My latest three. Full catalogue follows."

### Casing

- **Wordmark / hero headline**: ALL CAPS — `KALAMARICO`. Always Space Grotesk, always with the white→lime→orange gradient.
- **Section headings (h2)**: Title Case in display type, with **one accented word** per heading rendered through the gradient. Examples — "Latest *Releases*", "Listen & *Download*", "Sound exploration, *always evolving*."
- **Eyebrow labels** (above every section heading): Mono, **UPPERCASE**, very wide tracking (`0.3em`), lime. Examples — `DISCOGRAPHY`, `EVERYWHERE`, `THE LABEL`, `ABOUT`.
- **Meta strings** (date stamps, pill chips, scrolling chrome): mono, uppercase, narrower tracking (`0.18–0.2em`), grey or lime.
- **Body copy**: sentence case, normal English mechanics. No exclamation points, no marketing emoji.

### Tone rules

- **First‑person** for anything Kalamarico says about himself or the music. **Third‑person** for the label.
- **No emoji** anywhere in UI copy. (The codebase uses **one** musical‑note emoji — only inside a `console.log` Easter egg in `Footer.tsx`. It never reaches the rendered page.)
- **No exclamation points**, no "!". The energy is delivered through visuals, not punctuation.
- **No marketing jargon** — never "elevate", "unleash", "epic". Prefer the producer's vocabulary: *texture*, *rhythmic structure*, *atmospheric depth*, *hybrid setup*, *continuous improvement*, *catalogue*.
- **Dashes** (em or " — ") are the favourite punctuation for tagline‑like phrases: `Electronic Music Producer | Co‑CEO of Beta-Time Records`, `Continuous improvement — both in mixing and composition — is core…`.
- **Bilingual reality** — the site ships in English, but the codebase comments and component‑internal logs are in Spanish (`// Radio del aro de spawn:` etc.). Treat both as in‑brand.
- **Numbers stay precise** — release dates use `DD MMM YYYY` (`24 Jan 2026`); year‑only releases collapse to just the year. Track counts on EPs render as `EP · 4`. Never round, never fake a stat.

### Microcopy patterns

| Pattern | Example |
| --- | --- |
| Eyebrow → headline → one‑sentence subhead | `DISCOGRAPHY` / "Latest *Releases*" / "My latest three. Full catalogue follows." |
| Pill stat | "Madrid, Spain" with a pin icon, on the dark‑elevated chip |
| CTA | "Listen on Spotify" + Spotify icon. Never just "Click here" / "Learn more". |
| Filter tab | `ALL · 31`, `SINGLES · 26`, `EPS · 5` — mono, count after a middle‑dot or in a faded suffix |

---

## Visual foundations

### Palette

- **Surfaces** are a 6‑step ink ramp from `#050507` to `#3a3a44`. Every section sits on either `--ink-950` (the deepest), `--ink-900` (default body), or `--ink-800/700` (cards). Sections alternate `950 → 900 → 950 → 900` to create a faint vertical rhythm — never alternated with white.
- **Two accents, one swap**: lime `#a3e635` is the primary in the GREEN theme; orange `#f97316` is the complement. In the FIRE theme they switch roles. The swap is the **only** way colour ever changes — there are no light/dark variants per page.
- **Text** is a five‑step neutral ramp anchored on `#f5f5f7` (primary white) with `gray‑300` for body, `gray‑500` for muted, never pure black on grey.
- All accent tokens are stored as **RGB tuples** so consumers can compose alpha (`rgb(var(--color-accent) / 0.2)`); shadows and grids always lean on this.

### Type

- **Display** — *Space Grotesk* (400/500/600/700). Big, geometric, slightly mono‑width. Used for the wordmark, h1/h2/h3.
- **Body** — *Inter* (300/400/500/600/700). The site's default workhorse.
- **Mono / meta** — *JetBrains Mono* (400/500). Used exclusively for eyebrows, captions, date stamps, count badges, and console‑style stat strings. Always uppercase, always letter‑spaced.
- **Never** mix in serif, script, or "fun" display fonts. The system has exactly three families.

### Backgrounds

- **No imagery on full sections.** Sections are flat ink with optional overlays.
- **Grid overlay** (`.k-bg-grid`) — 48px × 48px lime hairlines at 6% alpha. Used on hero, label CTA card. Never on text‑heavy sections.
- **Noise overlay** (`.k-bg-noise`) — fractal SVG noise at 6% opacity, `mix-blend-overlay`. Adds a subtle film grain.
- **Gradient washes** appear ONLY as blurred radial blobs (`bg-accent/20 blur-[120px]`) inside cards — never as gradient *fills* of a section.
- **Bottom protection gradient** at the hero — `from-transparent to-ink-950` over the bottom 160px to fade the grid out smoothly into the next section.
- **Wordmark gradient** (white → lime‑soft → lime → orange) is animated horizontally (`gradient-shift`, 12s ease infinite) so the headline feels alive.

### Animation

- **Easing** — almost always `ease-out`. `ease-in` only for ramp‑ups (e.g. avatar zoom before the flashpoint). Cubic curves are stock — no custom springs.
- **Durations** — fast UI 150–300ms, fade‑in‑on‑scroll 400–600ms, theme cross‑fade 500ms, gradient drift 12s, glow pulse 6s. Avatar flashpoint sequence is its own choreography (~1.2s toggles, ~4.85s intro).
- **Patterns** —
  - `fade-up` (16px → 0, opacity 0 → 1, 700ms) on every section's reveal.
  - `pulse-glow` (opacity 0.35 ↔ 0.7, 6s) on small accent dots and the scroll indicator.
  - `gradient-shift` (background‑position 0% ↔ 100%, 12s) on the wordmark.
  - **Theme‑swap** is a global transition: every element interpolates `background-color`, `border-color`, `color`, `box-shadow`, `fill`, `stroke` over 500ms when `[data-theme]` changes on `<html>`.
  - **Particle canvas** — 260‑particle pool, lime "embers" radiating outward in idle, ember‑orange flames climbing in the fire state. This is signature; document it but don't recreate from scratch unless asked.
- **Reduced motion** — every animated path has a `@media (prefers-reduced-motion: reduce)` short‑circuit. Mocks should respect this.

### States

- **Hover (links, buttons)** — text goes white, border goes lime, card translates `-translate-y-0.5` to `-translate-y-1`, shadow gains an accent‑tinted glow. Surfaces lighten one ink step (`ink-900 → ink-800`).
- **Hover (release cards)** — `-translate-y-1`, border swaps to `accent`, image scales `1.04`, a soft accent blob blooms from the top‑right.
- **Active / pressed** — no shrink. The site doesn't use `active:scale-95`. Pressed state is implied by the immediate hover‑darken.
- **Focus** — relies on the browser default ring; designs must add a visible focus state if used in production.
- **Disabled** — not present in this product. Skip.

### Borders, radii, shadows

- **Borders** — 1px, almost always `--ink-700` (#1a1a1f) at full opacity, sometimes at `/60`. Borders go lime on hover. Never thicker than 1px.
- **Radii** — generous and consistent:
  - `rounded-md` (6–8px) for buttons / inputs
  - `rounded-xl` (12px) for inline cards (catalogue thumbnails)
  - `rounded-2xl` (16–20px) for featured hero cards, avatars
  - `rounded-3xl` (24px) for the big "Label" CTA card
  - `rounded-full` for chips, pills, social tabs, the play‑button affordance
  - `rounded-[4rem]` (64px) — the **signature** corner only used on the hero avatar plate
- **Shadow system** — three layers:
  1. **Drop** — soft black at `-8px to -12px` y‑offset, fairly tight blur. Used as default card lift.
  2. **Accent glow** — `0 0 32px -4px rgb(accent / 0.55)` — used on big CTAs and the featured release card on hover.
  3. **Inner ring** — `0 0 0 1px rgb(accent / 0.4)` — emulated as box‑shadow when an outline ring is needed without affecting layout.
- **No inner shadows** for depth. Depth comes from elevation steps and accent glows, not bevels.

### Layout

- **Container** — `max-w-6xl` (1152px) centered with `px-6` (24px) horizontal padding. Mobile inherits the same padding.
- **Section rhythm** — `py-28` (112px) top/bottom on every section. Hero is `min-h-[100svh]`.
- **Grid** — 1‑column on mobile, 2 or 3 on `md`/`lg`. Featured releases are 3‑up; full catalogue is 4‑up; streaming links are 4‑up.
- **Fixed** — `Navbar` is `fixed inset-x-0 top-0`, transparent at top, switches to `bg-ink-950/70 backdrop-blur-xl` after 16px of scroll. No other fixed UI.
- **Z‑index** — header at 50, particle canvas at base layer (`-inset-[10%]` so beams escape the avatar bounding box). Decorative gradients are `pointer-events-none`.
- **Transparency + blur** — used sparingly: the scrolled navbar (`backdrop-blur-xl`) and meta chips (`bg-ink-900/60 backdrop-blur`). Never on a primary surface or on text — always on a chip or a chrome bar.

### Imagery

- **Album art** — Spotify CDN, square, sharp colour, painted/3D look. The site embraces saturated covers and lets them carry the colour energy.
- **Avatars** — two 1024×1024 painted portraits of the artist (green / fire). Soft radial mask `radial-gradient(circle at center, black 65%, transparent 100%)` so they fade into the dark page rather than sitting on a square.
- **No stock imagery, no generic photography, no skeuomorphic UI mockups.** If a photo is needed and we don't have one, leave a placeholder.
- **Mood** — warm shadows + cool neon highlights + grain. Cinematic, slightly cyberpunk.

---

## Iconography

The site uses **`react-icons`** as its only icon source — specifically the FontAwesome (`react-icons/fa`) and Simple Icons (`react-icons/si`) packs, plus a handful from Heroicons (`react-icons/hi`). All icons are **inline SVG**, line‑and‑fill, stroke‑normalised by react-icons.

| Pack | When | Sample icons in use |
| --- | --- | --- |
| `react-icons/fa` (FontAwesome 6) | Streaming brand marks | `FaSpotify`, `FaSoundcloud`, `FaInstagram`, `FaFacebookF`, `FaYoutube`, `FaApple`, `FaBandcamp`, `FaDeezer` |
| `react-icons/si` (Simple Icons) | Niche / brand marks not in FA | `SiBeatport`, `SiTidal` |
| `react-icons/hi` (Heroicons v1) | UI affordances | `HiMenu`, `HiX`, `HiPlay`, `HiLocationMarker`, `HiExternalLink` |

**Sizing** — 16–22px in‑band, never above 22 except inside the play‑button affordance circle. Icons inherit `currentColor`; they switch to `accent-soft` on idle, white on hover.

**No emoji** in UI. **No unicode dingbats** as decoration (`★`, `✦`, etc.) — the site never reaches for them. The lone exception is the 🎵 in `Footer.tsx`'s console banner.

**No custom icon font, no SVG sprite sheet** — every icon is a tree‑shaken React import. For HTML‑only mocks, link react-icons via CDN or substitute exact equivalents from a generic CDN icon font (Lucide is the closest free match; flag the substitution).

**Logos** are the painted avatars — there is no separate wordmark glyph. The wordmark is rendered **as text** (Space Grotesk + gradient), not as an image.

---

## Skill / agent contract

This folder ships with a [`SKILL.md`](./SKILL.md) so it can be dropped into Claude Code or any Agent‑Skill runtime. The skill expects you to:

1. Read `colors_and_type.css` first.
2. Reuse `ui_kits/artist-website/*.jsx` components for any artist‑site mock.
3. Copy assets *out* of `assets/` rather than referencing them externally.
4. Default to GREEN theme; only swap to FIRE if the design context is hover/intro state.

---

## Caveats & things to verify

- **Fonts** are loaded from Google Fonts CDN — no local `.ttf`/`.woff2` was committed to the codebase. If you need the system to work offline, mirror Inter / Space Grotesk / JetBrains Mono into a local `fonts/` folder.
- **No separate logo glyph** exists — the brand mark is the painted avatar + the typed wordmark. If you need a small monochrome logo (e.g. a watermark on a slide deck) that asset doesn't exist; ask the user.
- **No second product surface** — the company is the artist project, and the only product is the website. There's no app, no docs site. UI kits cover only the artist website.
