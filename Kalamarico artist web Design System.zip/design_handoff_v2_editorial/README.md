# Handoff: Kalamarico — Artist Website v2 (Editorial · Cinemático)

## Overview

Production-ready handoff package for the **v2 editorial redesign** of [kalamarico.com](https://kalamarico.com) — Madrid-based electronic music producer & Co-CEO of Beta-Time Records.

The v2 is a **polish-level redesign** of the existing site: same sections, same dark palette, same green/fire dual theme — but with stronger editorial typography, magazine-style numbered section headers, three new catalogue layouts (grid / list / timeline), a release-detail modal with tracklist, refined cover art with catalog numbers, and tighter streaming/label/footer treatments.

## About the Design Files

The files in this bundle are **design references created in HTML** — a high-fidelity prototype showing the intended look, layout, and behavior. They are **not production code to copy directly**.

Your task is to **recreate this design in the existing kalamarico repo** (React 18 + Vite + Tailwind v3 + framer-motion) using the codebase's established patterns, components, and the existing `src/data/artist.ts` source-of-truth. Re-use existing primitives where possible (the avatar particle-canvas, the theme provider, etc.) — do not regress production logic.

## Fidelity

**High-fidelity (hifi).** Pixel-perfect mockup with final colors, typography, spacing, and interactions. Recreate it pixel-perfectly using Tailwind utility classes and the existing `src/index.css` theme tokens. The HTML uses raw CSS for portability; **translate every rule to Tailwind utility classes** in the React components (use `@apply` only where the existing repo already does).

## Stack

- **React 18.3** (already in the repo)
- **Vite** (already configured)
- **Tailwind v3** with the existing `tailwind.config.js` palette (`accent`, `accent-fire`, `ink-*`, `fg-*`)
- **framer-motion** for entry/scroll animations (already a dep) — replace the plain CSS animations with motion variants
- **react-icons** (FA + Si + Hi families) — replace the inline SVG stand-ins in `icons.jsx` with their react-icons counterparts (table below)
- **TypeScript** — every new component must be `.tsx` and consume the existing `Release`, `Social`, `Artist` types from `src/types/`

## Files in this bundle

| File | Purpose |
|---|---|
| `v2.html` | Self-contained reference prototype — open in browser to inspect interactions |
| `colors_and_type.css` | Design tokens (colors, type, spacing, radii, shadows, motion). Map these to `tailwind.config.js` and `src/index.css` |
| `styles.css` | v1 styles (the older site, included for reference of what's being replaced) |
| `data.js` | Sample release/social/bio data (subset of `src/data/artist.ts`) |
| `icons.jsx` | Inline SVG icons used in the prototype — **replace with react-icons in production** |
| `assets/avatar-green.jpeg`, `assets/avatar-fire.jpeg` | Painted portrait assets, already in the repo's `public/` |

## Screens / Views

This is a **single-page** site. One route, scrollable sections + a modal.

### Section order

1. **Navbar** — fixed, three-column grid (left links / center brand / right meta), turns opaque on scroll
2. **Hero** — wordmark + portrait + meta-row + ticker
3. **About** — sticky pull-quote + stat grid + bio + label index
4. **Tracks** — featured 3-up + filter switch + view switch (grid / list / timeline) + release modal
5. **Streaming** — 4-col grid of stores + 4-col grid of socials
6. **Label** — Beta-Time Records CTA card with stats
7. **Footer** — giant gradient wordmark + 4 column links + bottom meta bar

---

### 1. Navbar

- **Position:** `fixed top-0 inset-x-0 z-50`
- **Initial state:** transparent background
- **Scrolled state** (`scrollY > 16`): `bg-[rgb(5_5_7_/_0.78)] backdrop-blur-xl border-b border-white/[0.08]`
- **Layout:** `max-w-[1280px] mx-auto px-8 py-4 grid grid-cols-[1fr_auto_1fr] items-center gap-6`
- **Left side:** `About · Releases · Listen` — links spaced `gap-7`, font: `JetBrains Mono 11px / 0.22em tracking / uppercase / fg-3`. Hover: `text-white border-b border-accent`
- **Center:** "Kalamarico" — `Space Grotesk 600 14px / 0.04em / uppercase / white`
- **Right side:** "Live · MAD" with pulsing 6×6 lime dot (`@keyframes blink: 0,100%→opacity:1, 50%→opacity:.35, duration: 2.4s ease-in-out infinite`), then "Beta-Time ↗" link
- **Transition** between states: 300ms `cubic-bezier(0.16, 1, 0.3, 1)`

### 2. Hero

- **Padding:** `pt-40 pb-20` (160px / 80px)
- **Background layers** (absolutely positioned, `pointer-events-none`):
  - Grid: `linear-gradient` 96×96 cells, `rgba(255,255,255,0.04)` 1px lines, masked with `radial-gradient(ellipse at center, black 30%, transparent 80%)`
  - Glow: 70vw circle (max 900px), `radial-gradient(circle, rgb(var(--color-accent) / 0.18) 0%, transparent 60%)`, blur 60px, centered
- **Meta-row** (top, above the grid):
  - 4 items, `flex justify-between flex-wrap gap-6 mb-16`
  - Each: `JetBrains Mono 11px / 0.22em / uppercase / fg-5`. Bold parts in `fg-2 weight-500`
  - Content: `K · 01 — Artist`, `EST. 1996 — FastTracker → Now`, `Madrid, ES · 40.4°N 3.7°W`, `{releases.length} releases · 3 labels`
- **Main grid:** `grid grid-cols-[1.4fr_1fr] gap-16 items-center` (collapse to 1 col under 900px)
- **Left column:**
  - Eyebrow: lime dot + "Electronic music · producer"
  - **Wordmark "Kalamarico"** — `Space Grotesk 700, font-size: clamp(64px, 12vw, 180px), line-height: 0.9, letter-spacing: -0.04em`. Text gradient: `linear-gradient(135deg, #fff 0%, accent-soft 35%, accent 65%, accent-fire 100%)`, `background-size: 200% 100%`, animated with `@keyframes k-shift: 0/100% → background-position: 0% 50%, 50% → 100% 50%`, duration 14s ease-in-out infinite
  - Lede paragraph: `Space Grotesk 400, clamp(20px, 1.8vw, 26px), line-height 1.4, fg-2, max-width 480px, mt-8`
    > "Sound exploration, electronic texture, and a 30-year obsession with rhythmic structure — built in Madrid."
  - CTA row (`mt-12 flex gap-3 flex-wrap`):
    - **Primary:** lime bg, ink-950 text, `JetBrains Mono 11px / 0.22em / uppercase / weight-500`, `px-5 py-3`, **no border-radius** (sharp corners). Icon + "Listen on Spotify"
    - **Ghost:** transparent bg, white text, border `1px white/[0.14]`. Hover: border accent, text accent-soft
- **Right column — portrait:**
  - `aspect-[4/5]`, `rounded-[4px]`, `overflow-hidden`, `border border-white/[0.08]`, `cursor-pointer`
  - Image: `w-full h-full object-cover`, `filter: contrast(1.05) saturate(1.05)`, transitions `transform 800ms` to `scale(1.03)` on hover
  - Bottom gradient overlay: `linear-gradient(to top, rgba(5,5,7,0.7) 0%, transparent 50%)`
  - Top-left tag: "Calm state" / "Fire state" — mono 10px, white on `rgba(5,5,7,0.55)` blur
  - Bottom caption (flex justify-between items-end): "Latest release" label + release name (Space Grotesk 22px white) on left; release month (mono uppercase) on right
  - **Click toggles `data-theme="green"` ↔ `"fire"` on `<html>`**, swapping image src too — wire this through the existing theme provider
- **Ticker (below hero, `mt-24`):**
  - `border-y border-white/[0.08]`, `py-4`, `overflow-hidden`
  - Mask: `linear-gradient(to right, transparent, black 8%, black 92%, transparent)`
  - Inner track: `flex gap-12 w-max animate-[k2-scroll_60s_linear_infinite]` (`@keyframes k2-scroll: from translateX(0) → to translateX(-50%)`)
  - Render the latest 8 releases **twice** (so the loop seams) as: `<em>{cat#}</em> {name} — {month} · {type}`
  - `<em>` is mono accent-soft 12px, the rest is Space Grotesk 600 18px fg-3

### 3. About

- **Section padding:** `py-30` (120px), bg `ink-950`, container `max-w-[1280px] px-8 mx-auto`
- **Section header** (every section uses this same pattern):
  - Grid `grid-cols-[200px_1fr] gap-12 pb-14 border-b border-white/[0.08] mb-16 items-end`
  - Left: "01 / 04 — About" — Space Grotesk 500 14px fg-5, with `01 / 04` colored `accent`
  - Right: H1 — `Space Grotesk 600, clamp(40px, 5.2vw, 76px), line-height 1.02, letter-spacing -0.02em, white`. Two lines: "Sound exploration," / "always evolving." (second line in `accent-soft`, font-style normal even though the prototype uses `<em>`)
- **Body grid:** `grid grid-cols-[1fr_1.1fr] gap-24` (collapse to 1 col under 900px)
- **Left side (sticky `top-30 self-start`):**
  - Eyebrow "Pull quote" in fg-5 mono
  - Pull-quote: Space Grotesk 600 `clamp(28px, 2.4vw, 36px)`, line-height 1.15, letter-spacing -0.015em, white, `mt-2 mb-8`. The word "process" is wrapped in accent-soft.
  - **Stat grid 2×2** with 1px white/8 dividers (use `gap: 1px` on a colored bg trick): each cell is `bg-ink-950 p-5 flex flex-col gap-2`, value `Space Grotesk 600 36px white` with optional `<small>` in fg-5 14px/400 mt-1.5, label `mono 10px / 0.22em / uppercase / fg-5`
  - Stats: `releases / 3 labels / 30 yrs / MAD`
- **Right side (bio):**
  - First paragraph: 19px line-height 1.65 fg-3, with **drop cap "S"** (float left, Space Grotesk 600, 64px line-height 0.85, accent-soft, `padding: 6px 12px 0 0`)
  - Second paragraph: 17px
  - Below, "Released on" eyebrow + numbered label list:
    - `<ul>` rows `flex justify-between items-baseline py-3.5 border-b border-white/[0.08]`, label `Space Grotesk 500 18px fg-2`, index `mono 11px fg-5` formatted "01 ↗"
    - Hover: label → accent-soft

### 4. Tracks

- bg `ink-900`, padding `py-30`, same container
- Section header: "02 / 04 — Discography", H1 "Latest **releases**" (accent-soft on second word) + sub-line "three featured · full catalogue follows" in fg-5 weight-400 letter-spacing-0
- **Featured row** (`mt-8`):
  - `grid grid-cols-[1.4fr_1fr_1fr] gap-6 border-t border-white/[0.08] pt-8 mb-20`
  - Each card: `flex flex-col gap-4 cursor-pointer`. **First card uses `aspect-[4/5]`**, others `aspect-square`. First card name is 32px, others 22px.
  - Meta row: `flex justify-between items-baseline`, type label in accent-soft mono, date in fg-5 mono
  - "Listen" line: mono 11px fg-3 + play icon
- **Catalogue header** (between featured and grid):
  - Layout `grid grid-cols-[1fr_auto] gap-8 items-end`
  - Left: eyebrow + H2 "{filtered.length} {filter} · 2024 → 2026"
  - Right: two **view-switch** components side by side
    - **Filter switch:** All / Singles / EPs (with counts)
    - **View switch:** Grid / List / Timeline
    - Each switch: `inline-flex border border-white/[0.14]`. Buttons: `px-4 py-2.5 mono 11px / 0.22em / uppercase / fg-4 / cursor-pointer / border-r border-white/[0.14]`. Last button no right border. Active: `bg-accent text-ink-950`. Hover: text-white.
- **Catalogue body — three views:**

#### Grid view
- `grid grid-cols-4 gap-6` (3 cols ≤900, 2 cols ≤600)
- Each item: `flex flex-col gap-3 cursor-pointer`. Square cover + meta row (name + year/type)
- Name: Space Grotesk 600 15px white. Hover: accent-soft.
- Type/year: mono 10px fg-5

#### List view (Discogs/Beatport-like)
- Header row: `grid grid-cols-[56px_64px_1fr_100px_80px_90px_36px] gap-5 px-4 py-3.5 border-y border-white/[0.14]`. Columns: Cat# / Cover / Title / Type / Year / Tracks / (play). Header is mono 10px fg-5 uppercase.
- Data rows: same grid, `border-b border-white/[0.08]`, hover `bg-white/[0.025]`
- Cat# (mono 11px fg-5), 56×56 mini cover (cover with everything but title hidden, title scaled to 8px), title block (Space Grotesk 500 16px white + sub-line "Kalamarico · {month}" in mono 10px fg-5), type pill (mono 10px — EP in accent-soft, SINGLE in fg-3), year + tracks (mono 12px fg-3), 36×36 circle play icon (border, hover fills accent)
- Mobile: collapse to `grid-cols-[56px_1fr_36px]`, hide ix/typ/yr/tracks columns

#### Timeline view
- Hint above: "Scroll horizontally →" in mono 11px fg-5
- Container: `relative -mx-8` (full-bleed within section)
- Inner: `flex gap-8 items-end overflow-x-auto p-8 scroll-snap-type-x-mandatory`
- Custom scrollbar: 4px height, accent thumb on white/8 track
- For each year (descending), insert a **year marker**: 40px wide column, vertical line + vertical year label (Space Grotesk 600 24px accent-soft, `writing-mode: vertical-rl`, letter-spacing 0.1em), `align-self: stretch`, content justified end
- Then year's releases as cards: `flex-none w-[220px] scroll-snap-align-start flex flex-col gap-3 cursor-pointer`. Square cover + meta + name (Space Grotesk 600 16px)

#### Release Modal
- Triggered by clicking any release (featured / grid / list / timeline)
- Backdrop: `fixed inset-0 z-100 bg-[rgba(5,5,7,0.85)] backdrop-blur-xl flex items-center justify-center p-8`. Fade in 300ms, `pointer-events-none` until open. **Lock body scroll while open.**
- Modal: `w-full max-w-[980px] max-h-[90vh] overflow-y-auto bg-ink-900 border border-white/[0.14] translate-y-5` → `translate-y-0` on open, 300ms easing
- Layout: `grid grid-cols-[1fr_1.1fr]` (1 col under 800px). Left = full-bleed cover (with `cover-title` font scaled to clamp(28px, 3vw, 44px) and `cover-num` to clamp(80px, 14vw, 200px) bottom-20). Right = body padding 10
- Body content (`flex flex-col gap-6 p-10`):
  - Eyebrow with cat# (lime dot + cat code)
  - H2 release name `Space Grotesk 600 clamp(28px, 3vw, 40px)`
  - Meta row: 4 stacked label/value pairs (`flex flex-wrap gap-5`)
    - Type (Single / EP · N tracks), Released (full date), Artist (Kalamarico), Label (Beta-Time Records for EPs, else Kalamarico)
  - Tracklist eyebrow + `<ol>` with rows `grid grid-cols-[32px_1fr_auto] gap-4 py-3 border-b border-white/[0.08]`, index mono 11px fg-5 / name Space Grotesk 500 15px / dur mono 12px fg-4. Hover: name → accent-soft
  - **Track synthesis logic** (since real tracklist isn't in source data): for `trackCount` 1, single track named the release. For >1, track 1 = release name, then variants from `["Original Mix", "Extended Mix", "Dub Mix", "Radio Edit", "Beta-Time Edit"]`. Duration `${4 + (i % 3)}:${String(20 + i*7 % 40).padStart(2,"0")}`. **In production, replace this with real data from the API.**
  - CTA row: Primary "Open in Spotify" + Ghost "SoundCloud"
- Close button: top-right `36×36 rounded-full bg-[rgba(5,5,7,0.6)] border-white/[0.14] text-white`. Hover: bg-accent text-ink-950. **ESC also closes.**

### 5. Streaming

- bg `ink-950`, same section header pattern ("03 / 04 — Listen", H1 "Listen & **follow**")
- Two stacked groups: "Streaming & stores" / "Social"
- Each group: eyebrow above, then a `grid grid-cols-4 gap-px bg-white/[0.08] border border-white/[0.08]` (the gap-px-on-colored-bg divider trick). 2 cols on mobile.
- Each tile: `bg-ink-950 p-7 px-6 flex flex-col gap-4 cursor-pointer relative overflow-hidden`. Hover: `bg-ink-900`
- Content stacked: 32×32 icon (accent-soft), then label "Stream" / "Follow" (mono 10px fg-5), then platform name (Space Grotesk 600 18px white)
- Top-right: index "01" — mono 10px fg-6
- Bottom-right: "Open ↗" — mono 11px fg-5 → accent-soft + translateX(4px) on hover
- **Use react-icons** (see icon table below) — sized 28px

### 6. Label (Beta-Time Records)

- bg `ink-900`, same section header ("04 / 04 — The Label", H1 "Curating **electronic music**")
- Card: `relative overflow-hidden border border-white/[0.14] p-20 px-16` (`p-12 px-7` on mobile)
- Background: `linear-gradient(135deg, ink-800 0%, ink-950 100%)` + grid 64×64 in `rgba(255,255,255,0.04)` masked from top-right + glow circle 500×500 top-right -100/-100 with `rgba(accent / 0.18)` blurred 60px
- Inner grid: `grid grid-cols-2 gap-16 items-end`
- **Left side:**
  - Eyebrow with dot: "Co-CEO since 2023"
  - Brand mark: "Beta-Time / Records" — Space Grotesk 700 `clamp(40px, 6vw, 88px)`, line-height 0.9, letter-spacing -0.03em. The word "Records" wrapped with `linear-gradient(135deg, accent, accent-fire)` text-clip
  - Lede: same pattern as hero, mt-8 max-width-[480px]
- **Right side:**
  - Stats 3-col with same divider trick. Cells: `bg-[rgba(5,5,7,0.6)] backdrop-blur-md p-4`. Value Space Grotesk 600 24px white, label mono 9px fg-5 mt-2
  - Stats: `42+ Releases / 18 Artists / 2023 Founded`
  - CTA row: Primary "Visit website" + Ghost "Beatport store"

### 7. Footer

- bg `ink-950`, `py-16 pt-16 pb-8`, border-top `white/[0.08]`
- **Giant wordmark "KALAMARICO"** — Space Grotesk 700, `clamp(64px, 14vw, 220px)`, line-height 0.85, letter-spacing -0.04em, gradient `linear-gradient(135deg, rgba(255,255,255,0.95), accent-soft 50%, accent 100%)` text-clipped, `mb-12`
- 4-column row `grid grid-cols-[2fr_1fr_1fr_1fr] gap-8 pb-8 border-b border-white/[0.08]` (2-col on mobile)
  - Col 1: "MADRID · ES" h4 (mono 10px fg-5), then descriptor body 14px fg-3 max-w-[340px], then mailto in accent-soft mono uppercase
  - Cols 2/3/4: "SITE / LISTEN / FOLLOW" with link lists. Links: Space Grotesk 500 15px fg-2 → accent-soft on hover
- Bottom bar `pt-6 flex justify-between flex-wrap gap-4`: copyright on left ("© 2025 **Kalamarico** / Beta-Time Records"), version on right ("v2 · Editorial · 2025")
- All bottom-bar text mono 10px / 0.2em / uppercase / fg-5, bold parts fg-3

---

## Cover Component (used in featured / grid / list mini / timeline / modal)

A reusable component:

```tsx
interface CoverProps { release: Release; }
// styles consume CSS vars --c1 (release.color[0]) and --c2 (release.color[1])
```

Stack of layers (bottom→top):
1. **`cover-bg`** — `radial-gradient(circle at 30% 30%, var(--c1) 0%, transparent 55%), radial-gradient(circle at 70% 80%, var(--c2) 0%, transparent 60%), linear-gradient(180deg, var(--c1) 0%, #050507 100%)`. `filter: saturate(1.1)`
2. **`cover-grid`** — 14% × 14% grid lines `rgba(255,255,255,0.4)` 1px, opacity 0.22, `mix-blend-mode: overlay`
3. **`cover-noise`** — SVG fractal noise turbulence (baseFrequency 1.2, 2 octaves), opacity 0.18, `mix-blend-mode: overlay`
4. **`cover-vignette`** — `radial-gradient(ellipse at 50% 100%, rgba(5,5,7,0.85) 0%, transparent 60%)`
5. **`cover-cat`** — top-left, mono 10px / 0.25em / uppercase / `rgba(255,255,255,0.8)`. Format: `KAL001` for singles, `BTR-EP010` for EPs (computed from id + type)
6. **`cover-year`** — top-right, same style
7. **`cover-num`** — giant id number bottom-left bottom-14, Space Grotesk 700 `clamp(60px, 9vw, 140px)`, line-height 0.85, `rgba(255,255,255,0.16)`, letter-spacing -0.05em, `mix-blend-mode: overlay`
8. **`cover-title`** — bottom, Space Grotesk 600 `clamp(15px, 1.5vw, 22px)`, white, text-shadow `0 2px 16px rgba(0,0,0,0.5)`
9. **`cover-play`** — bottom-right `36×36 rounded-full bg-[rgba(5,5,7,0.6)] backdrop-blur-md border-white/[0.2]`. Hover: bg-accent, scale 1.08

The mini list-view variant **hides cover-num, cover-grid, cover-cat, cover-year, cover-play** and uses 8px title font.

## Interactions & Behavior

| Interaction | Trigger | Behavior |
|---|---|---|
| Theme swap | Click hero portrait | `<html data-theme>` ↔ green/fire; portrait image src swaps; all accent colors transition over 500ms |
| Navbar scroll-state | `window.scroll > 16px` | Adds `is-scrolled` class with bg + blur + border |
| Filter switch | Click All/Singles/EPs | Filters the catalogue array, updates count in H2 |
| View switch | Click Grid/List/Timeline | Swaps catalogue layout; persist selection in URL query (`?view=list`) for shareability |
| Open release | Click any release card (featured / grid / list / timeline) | Opens modal, locks body scroll |
| Close release | Click backdrop / X / ESC | Closes modal, unlocks scroll |
| Cover hover | Mouse over | Play button fills accent + scales 1.08 |
| Stat hover | Mouse over label list / nav links | Color → accent-soft |
| Ticker | Always | Loops infinitely (60s linear), masked edges |
| Wordmark | Always | Background-position shifts 0%↔100% over 14s |
| Reduced motion | `prefers-reduced-motion: reduce` | All animations short-circuit to 0.01ms (already in `colors_and_type.css`) |

## State Management

This is a small enough surface to live in a single page-level component using `useState`:

```tsx
const [theme, setTheme] = useState<'green' | 'fire'>('green');
const [filter, setFilter] = useState<'all' | 'single' | 'ep'>('all');
const [view, setView] = useState<'grid' | 'list' | 'timeline'>('grid');
const [activeRelease, setActiveRelease] = useState<Release | null>(null);
const [scrolled, setScrolled] = useState(false);
```

`activeRelease` should become URL-driven (`?release=15`) for deep-linkable share URLs. Use `useSearchParams` (React Router) or window history if you don't have a router.

The theme should flow through your existing `ThemeProvider` (don't fork the production logic).

## Design Tokens

All defined in `colors_and_type.css` — port these into `tailwind.config.js` (`theme.extend`) and `src/index.css` (CSS vars). The repo already has most of them; **the v2 introduces only one structural change: the rule colors `rgba(255,255,255,0.08)` (rule) and `rgba(255,255,255,0.14)` (rule-strong) — add as `border-white/[0.08]` / `border-white/[0.14]` Tailwind classes** (no config change needed).

| Token | Value |
|---|---|
| `accent` (green theme) | `#a3e635` |
| `accent-soft` | `#bef264` |
| `accent-glow` | `#84cc16` |
| `accent` (fire theme) | `#f97316` |
| `accent-soft` (fire) | `#fb923c` |
| `accent-glow` (fire) | `#ef4444` |
| `ink-950 → ink-500` | `#050507 / #0a0a0c / #111114 / #1a1a1f / #26262d / #3a3a44` |
| `fg-1 → fg-6` | `#f5f5f7 / #e5e7eb / #d1d5db / #9ca3af / #6b7280 / #4b5563` |
| **rule** | `rgba(255,255,255,0.08)` |
| **rule-strong** | `rgba(255,255,255,0.14)` |
| `font-display` | `"Space Grotesk", "Inter", sans-serif` |
| `font-sans` | `"Inter", sans-serif` |
| `font-mono` | `"JetBrains Mono", monospace` |
| `ease-out` | `cubic-bezier(0.16, 1, 0.3, 1)` |
| `dur-quick / base / theme / slow` | `150ms / 300ms / 500ms / 700ms` |

### Type scale used in v2

| Class | Family / weight / size / line / tracking |
|---|---|
| Wordmark | Space Grotesk 700 / clamp(64,12vw,180) / 0.9 / -0.04em |
| H1 | Space Grotesk 600 / clamp(40,5.2vw,76) / 1.02 / -0.02em |
| H2 | Space Grotesk 600 / clamp(28,3vw,40) / 1.1 / -0.015em |
| Lede | Space Grotesk 400 / clamp(20,1.8vw,26) / 1.4 / -0.005em |
| Body | Inter 400 / 17px / 1.65 |
| Eyebrow | JetBrains Mono 500 / 11px / 0.28em / uppercase |
| Caption | JetBrains Mono / 10–11px / 0.2–0.25em / uppercase |
| Footer mark | Space Grotesk 700 / clamp(64,14vw,220) / 0.85 / -0.04em |

## Icon mapping (replace inline SVG with react-icons)

| `K_ICONS` key | react-icons import |
|---|---|
| Spotify | `FaSpotify` from `react-icons/fa` |
| SoundCloud | `FaSoundcloud` from `react-icons/fa` |
| Beatport | `SiBeatport` from `react-icons/si` |
| Apple | `FaApple` from `react-icons/fa` |
| Bandcamp | `FaBandcamp` from `react-icons/fa` |
| Deezer | `FaDeezer` from `react-icons/fa` |
| Tidal | `SiTidal` from `react-icons/si` |
| Instagram | `FaInstagram` from `react-icons/fa` |
| Facebook | `FaFacebook` from `react-icons/fa` |
| YouTube | `FaYoutube` from `react-icons/fa` |
| Play | `FaPlay` from `react-icons/fa` |
| External | `HiArrowTopRightOnSquare` from `react-icons/hi2` |
| X (close) | `HiXMark` from `react-icons/hi2` |

## Assets

- **`assets/avatar-green.jpeg`** and **`assets/avatar-fire.jpeg`** — already in `public/` of the kalamarico repo. Re-use the production paths (don't duplicate).
- **Cover artwork** — synthesized gradients in this prototype. In production, surface real artwork URLs from your data source; fall back to the gradient generator (using the `release.color` tuple) when missing.

## Implementation order

1. Add the two rule color utilities (no config change — use `border-white/[0.08]` / `border-white/[0.14]`)
2. Build `<Cover />` first — every catalogue view depends on it
3. Build the section-header partial (`<SectionHead num="01 / 04" label="About" />`) — shared by 4 sections
4. Build sections in order, swap them in one at a time alongside the existing v1
5. Build `<ReleaseModal />` last; wire from cover click handlers
6. Add a feature flag (`?v=2` query param) to toggle between v1 and v2 in production while testing
7. Once approved, retire v1 components

## Responsive behavior

Three breakpoints are baked in:

| Breakpoint | Trigger | Key changes |
|---|---|---|
| Tablet | `max-width: 900px` | Hero grid → 1 col; About grid → 1 col; Featured → 1 col; Grid → 3 cols; Section padding 80px; Label grid → 1 col; Footer → 2 cols |
| Phone | `max-width: 700px` | Container padding 20px; Section padding 64px; Section header stacks (number above heading); Navbar collapses to brand + status only (links hidden); Wordmark `clamp(56px,18vw,96px)`; CTAs full-width-flex; Ticker slows to 90s, smaller; Sticky-side becomes static; Stat values 26px; Bio 15px; Drop cap 44px; Tracks switches go full-width and stack; Catalogue grid → 2 cols; Cover internals scale down (cat# 8px, title 13px, num clamped 48–80px); List rows tighten; Timeline cards 160px wide; **Modal goes fullscreen** (height 100vh, no border, padding 0); Streaming → 2 cols; Label card padding 40/24, stats stay 3-up but smaller; Footer mark `clamp(56px,22vw,96px)`, footer cols → 2; Buttons 11/14 padding |
| Small phone | `max-width: 420px` | Wordmark fixed 56px; **Hero meta-row hidden** to free vertical space; Catalogue/Streaming gaps tighten; Cover num shrinks to 44px |

**Touch devices** (`@media (hover: none)`) — all `:hover` color/transform effects are disabled to avoid sticky hover states after tap.

**Modal on phone** — full-bleed, no rounded corners, scrolls within its own container, slide-up entrance from `translateY(40px)`. Cover becomes 16:10 banner so the body content shows above the fold.

**Hit targets** — all interactive elements ≥ 36×36px on phone. CTAs flex to fill row width.

## Caveats

- **Tracklist data is synthesized** in the prototype. Connect the modal to real tracklist data from the source (`src/data/artist.ts` doesn't have tracklists today — extend the schema or fetch from Spotify API)
- **Catalog codes** (`KAL001`, `BTR-EP010`) are computed from id + type — formalize the format with the user before shipping
- **Beta-Time stats** ("42+ releases, 18 artists, 2023 founded") are placeholder — replace with real values
- **Email** `hello@kalamarico.com` is a placeholder — confirm the real address
- The hero portrait click toggling theme is a **prototype-only easter egg**; in production keep the existing avatar particle-canvas and add a separate theme toggle (e.g., in the footer or a settings menu)
- Production already has framer-motion entry animations — re-apply equivalents on the new sections; the prototype uses plain CSS for portability
