// Subset of src/data/artist.ts — enough to drive the UI kit.
window.kalamaricoData = {
  name: "Kalamarico",
  tagline: "Electronic Music Producer | Co-CEO of Beta-Time Records",
  location: "Madrid, Spain",
  bio: [
    "Since my first sequences in FastTracker nearly 30 years ago, I've developed a creative approach focused on sound exploration, electronic texture design, and technical evolution in music production. I work with a hybrid setup of software and hardware, with a particular interest in balancing rhythmic structure and atmospheric depth.",
    "As Co-CEO of Beta-Time Records, I manage projects, curate releases, and collaborate with artists to shape proposals that stand out in today's electronic music scene. Continuous improvement — both in mixing and composition — is a core part of my creative process."
  ],
  labels: ["Beta-Time Records", "Vanta Record", "Techno Drum Records", "Nothing But"],
  releases: [
    { id: "1", name: "Too Late",          type: "SINGLE", date: "2026-04-03", trackCount: 1, color: ["#f97316", "#7c2d12"] },
    { id: "2", name: "Winter Chaser",     type: "SINGLE", date: "2026-01-24", trackCount: 1, color: ["#67e8f9", "#0e7490"] },
    { id: "3", name: "Prometheus",        type: "SINGLE", date: "2026-01-09", trackCount: 2, color: ["#fde047", "#7c2d12"] },
    { id: "4", name: "The Journey",       type: "SINGLE", date: "2025-12-26", trackCount: 1, color: ["#a78bfa", "#3b0764"] },
    { id: "5", name: "Snow Drift",        type: "SINGLE", date: "2025-11-21", trackCount: 2, color: ["#bae6fd", "#1e3a8a"] },
    { id: "6", name: "The Game Continues", type: "EP",     date: "2025-11-14", trackCount: 4, color: ["#a3e635", "#365314"] },
    { id: "7", name: "Echoes of Addiction", type: "SINGLE", date: "2025-10-10", trackCount: 1, color: ["#f472b6", "#831843"] },
    { id: "8", name: "Through the Dragon's Gate", type: "SINGLE", date: "2025-10-03", trackCount: 1, color: ["#f97316", "#450a0a"] },
    { id: "9", name: "Eugenie 100",       type: "SINGLE", date: "2025-06-06", trackCount: 1, color: ["#fbbf24", "#451a03"] },
    { id: "10", name: "The Game",          type: "EP",     date: "2025-02-14", trackCount: 5, color: ["#84cc16", "#0a0a0c"] },
    { id: "11", name: "This Is Raveolution", type: "SINGLE", date: "2025-01-29", trackCount: 1, color: ["#22d3ee", "#0c4a6e"] },
    { id: "12", name: "Federado",          type: "SINGLE", date: "2025-01-10", trackCount: 1, color: ["#ef4444", "#1c1917"] },
    { id: "13", name: "Crouching Tiger Hidden Dragon", type: "SINGLE", date: "2025-01-03", trackCount: 1, color: ["#fb923c", "#3f0a0a"] },
    { id: "14", name: "Signal Dimensions", type: "SINGLE", date: "2024-12-06", trackCount: 1, color: ["#60a5fa", "#0c0a09"] },
    { id: "15", name: "Mare's-Nest Temple", type: "SINGLE", date: "2024-10-11", trackCount: 1, color: ["#facc15", "#1c1917"] },
    { id: "16", name: "2 State",           type: "EP",     date: "2024-07-05", trackCount: 4, color: ["#34d399", "#064e3b"] }
  ],
  socials: [
    { label: "Spotify",     kind: "stream" },
    { label: "SoundCloud",  kind: "stream" },
    { label: "Apple Music", kind: "stream" },
    { label: "Beatport",    kind: "stream" },
    { label: "Deezer",      kind: "stream" },
    { label: "Tidal",       kind: "stream" },
    { label: "Bandcamp",    kind: "stream" },
    { label: "Instagram",   kind: "social" },
    { label: "Facebook",    kind: "social" },
    { label: "YouTube",     kind: "social" }
  ]
};
