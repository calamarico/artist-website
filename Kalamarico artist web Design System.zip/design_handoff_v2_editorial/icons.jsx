// Inline-SVG stand-ins for the react-icons used in kalamarico.com.
// All icons inherit currentColor; size prop is in px.
const Icon = ({ d, size = 18, vb = "0 0 24 24", stroke = false }) => (
  <svg
    viewBox={vb}
    width={size}
    height={size}
    fill={stroke ? "none" : "currentColor"}
    stroke={stroke ? "currentColor" : "none"}
    strokeWidth={stroke ? 2 : 0}
    strokeLinecap="round"
    strokeLinejoin="round"
    aria-hidden="true"
  >
    {typeof d === "string" ? <path d={d} /> : d}
  </svg>
);

window.K_ICONS = {
  Spotify: ({ size }) => (
    <Icon size={size} d="M12 2a10 10 0 100 20 10 10 0 000-20zm4.5 14.4a.6.6 0 01-.83.2c-2.27-1.4-5.13-1.7-8.5-.93a.6.6 0 11-.27-1.18c3.7-.84 6.86-.5 9.4 1.07.28.17.37.55.2.84zm1.2-2.7a.75.75 0 01-1.04.25c-2.6-1.6-6.55-2.06-9.62-1.13a.75.75 0 01-.44-1.43c3.5-1.07 7.86-.55 10.85 1.27.36.22.47.7.25 1.04zm.1-2.8c-3.13-1.86-8.3-2.03-11.3-1.12a.9.9 0 11-.52-1.72c3.45-1.05 9.16-.85 12.76 1.28a.9.9 0 11-.94 1.55z" />
  ),
  SoundCloud: ({ size }) => (
    <Icon size={size} d="M3 13a1 1 0 011 1v3a1 1 0 11-2 0v-3a1 1 0 011-1zm3-2a1 1 0 011 1v6a1 1 0 11-2 0v-6a1 1 0 011-1zm3-1a1 1 0 011 1v8a1 1 0 11-2 0v-8a1 1 0 011-1zm3-3a1 1 0 011 1v11a1 1 0 11-2 0V8a1 1 0 011-1zm9 1a5 5 0 014.9 4h.1a4 4 0 010 8h-9V9a5 5 0 014-3z" />
  ),
  Beatport: ({ size }) => (
    <Icon size={size} d={<><circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" strokeWidth="2" /><circle cx="12" cy="14" r="4" fill="currentColor" /></>} />
  ),
  Apple: ({ size }) => (
    <Icon size={size} d="M16 1.7c.1 1.3-.4 2.6-1.2 3.5-.8 1-2.2 1.7-3.4 1.6-.1-1.3.5-2.6 1.3-3.4.9-.9 2.3-1.6 3.3-1.7zM20 17c-.5 1-1 2-1.7 2.9-1 1.3-2.4 2.9-4 2.9-1.4 0-1.8-.9-3.7-.9s-2.4.9-3.7.9c-1.6 0-3-1.5-3.9-2.7-2.4-3.4-4.2-9.6-1.8-13.8 1.2-2 3.3-3.3 5.6-3.3 1.6 0 3.1.9 3.8.9.8 0 2.6-1.1 4.4-1 .8 0 3 .3 4.4 2.4-3.7 2.2-3.1 7.4.6 8.6z" />
  ),
  Bandcamp: ({ size }) => (
    <Icon size={size} d="M0 18l7-12h17l-7 12z" vb="0 0 24 24" />
  ),
  Deezer: ({ size }) => (
    <Icon size={size} d={<><rect x="2" y="14" width="4" height="3" /><rect x="7" y="14" width="4" height="3" /><rect x="12" y="14" width="4" height="3" /><rect x="17" y="14" width="4" height="3" /><rect x="7" y="10" width="4" height="3" /><rect x="12" y="10" width="4" height="3" /><rect x="17" y="10" width="4" height="3" /><rect x="12" y="6" width="4" height="3" /><rect x="17" y="6" width="4" height="3" /><rect x="17" y="3" width="4" height="2" /></>} />
  ),
  Tidal: ({ size }) => (
    <Icon size={size} d={<><polygon points="4,6 8,10 12,6 8,2" /><polygon points="12,6 16,10 20,6 16,2" /><polygon points="8,14 12,18 16,14 12,10" /></>} />
  ),
  Instagram: ({ size }) => (
    <Icon size={size} d={<><rect x="3" y="3" width="18" height="18" rx="5" fill="none" stroke="currentColor" strokeWidth="2" /><circle cx="12" cy="12" r="4" fill="none" stroke="currentColor" strokeWidth="2" /><circle cx="17" cy="7" r="1.2" /></>} />
  ),
  Facebook: ({ size }) => (
    <Icon size={size} d="M13 22v-9h3l1-4h-4V6.5c0-1 .3-1.5 1.7-1.5H17V1.5C16.5 1.4 15.6 1.3 14.5 1.3 11.7 1.3 10 3 10 6v3H7v4h3v9z" />
  ),
  YouTube: ({ size }) => (
    <Icon size={size} d="M22 7.5a3 3 0 00-2.1-2.1C18.1 5 12 5 12 5s-6.1 0-7.9.4A3 3 0 002 7.5C1.5 9.3 1.5 12 1.5 12s0 2.7.5 4.5a3 3 0 002.1 2.1C5.9 19 12 19 12 19s6.1 0 7.9-.4a3 3 0 002.1-2.1c.5-1.8.5-4.5.5-4.5s0-2.7-.5-4.5zM10 15.5v-7l6 3.5z" />
  ),
  Play: ({ size }) => <Icon size={size} d="M6 4l14 8-14 8z" />,
  Menu: ({ size }) => <Icon size={size} stroke d="M3 6h18M3 12h18M3 18h18" />,
  X: ({ size }) => <Icon size={size} stroke d="M6 6l12 12M6 18L18 6" />,
  Pin: ({ size }) => <Icon size={size} d="M12 2a7 7 0 017 7c0 5-7 13-7 13S5 14 5 9a7 7 0 017-7zm0 4a3 3 0 100 6 3 3 0 000-6z" />,
  External: ({ size }) => <Icon size={size} stroke d="M14 5h5v5M19 5L10 14M19 13v5a1 1 0 01-1 1H6a1 1 0 01-1-1V6a1 1 0 011-1h5" />
};
