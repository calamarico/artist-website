---
name: kalamarico-design
description: Use this skill to generate well-branded interfaces and assets for Kalamarico (Madrid electronic-music producer / Co-CEO of Beta-Time Records), either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

## Quick reference

- **Stack** Dark single-page artist site. Tailwind v3 + framer-motion in production; this skill ships a JSX/CSS recreation under `ui_kits/artist-website/`.
- **Default theme** GREEN (lime `#a3e635` primary, ember orange complement). FIRE theme is the hover/intro state — toggled by `[data-theme="fire"]` on `<html>`.
- **Type** Space Grotesk (display) · Inter (body) · JetBrains Mono (eyebrow / caption). All from Google Fonts; loaded by `colors_and_type.css`.
- **Voice** First-person, technical, no emoji, no exclamation points, sentence case. Dashes — like this — are the favourite punctuation. Eyebrows are mono UPPERCASE.
- **Wordmark** Always rendered as text (Space Grotesk 700, white→lime→orange gradient) — not as a logo image.
- **Avatars** Two painted 1024×1024 portraits in `assets/`: `avatar-green.jpeg` (idle) and `avatar-fire.jpeg` (hover). Soft radial mask, never on a solid square.
- **Iconography** `react-icons` (FA + Si + Hi). For HTML mocks, use the inline SVGs in `ui_kits/artist-website/icons.jsx` or substitute Lucide.
